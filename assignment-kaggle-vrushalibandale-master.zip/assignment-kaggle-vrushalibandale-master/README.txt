1. My session.csv file is about 625 MB so Git was not accepting the file as stated by Tej and Vivek
I did not attached csv file in the git but submitted it on blackboard.